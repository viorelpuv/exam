REM ***** sample batch file to set up GPC GNU Pascal for Mingw *****
@echo off
set prompt=GPC-mingw: $p$g
set PATH=D:\visiliy\dev_gnu_pascal\bin;%PATH%
set C_INCLUDE_PATH=D:\visiliy\dev_gnu_pascal\include
set GCC_BASE=3.4.5
set GPC_EXEC_PREFIX=D:\visiliy\dev_gnu_pascal\libexec\gcc\mingw32
set LIBRARY_PATH=D:\visiliy\dev_gnu_pascal\lib;D:\visiliy\dev_gnu_pascal\lib\gcc\mingw32\%GCC_BASE%
set GPC_UNIT_PATH=D:\visiliy\dev_gnu_pascal\lib\gcc\mingw32\%GCC_BASE%\units;D:\visiliy\dev_gnu_pascal\units;D:\visiliy\dev_gnu_pascal\units\winapi;D:\visiliy\dev_gnu_pascal\units\objects;D:\visiliy\dev_gnu_pascal\units\sysutils;D:\visiliy\dev_gnu_pa
